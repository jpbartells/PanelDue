/*
 * Dummy header to avoid unnecessary includes
 */

#ifndef ASF_H
#define ASF_H

#endif // ASF_H
