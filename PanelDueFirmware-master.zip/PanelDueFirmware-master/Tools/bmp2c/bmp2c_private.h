/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef BMP2C_PRIVATE_H
#define BMP2C_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.0.2.72"
#define VER_MAJOR	0
#define VER_MINOR	0
#define VER_RELEASE	2
#define VER_BUILD	72
#define COMPANY_NAME	"nimp software"
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"please visit www.nimp.co.uk/software for updates"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"Copyright (c) 2007, Sebastien Riou"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"bmp2c.exe"
#define PRODUCT_NAME	"bmp2c"
#define PRODUCT_VERSION	"0002"

#endif /*BMP2C_PRIVATE_H*/
